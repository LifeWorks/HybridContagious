title of file
normal-pop_size-degree-threshold-mean-std

in the file
column 1: probability
column 2: mean saturation level
column 3: std saturation level
column 4: mean saturation step
column 5: std saturation step
column 6: min saturation step
column 7: max saturation step
